package analysis_and_design;

/* Αυτή η κλάση/λειτουργία υλοποιείται εξωτερικά του πληροφοριακού συστήματος 
   και αφορά την περίπτωση χρήσης επιλογή προτεινόμενης παραγγελίας φρούτων 
   από τον Υπεύθυνο Αγοράς */

public class Calculating_app {

	public void send_data() {
		throw new UnsupportedOperationException();
	}
}
